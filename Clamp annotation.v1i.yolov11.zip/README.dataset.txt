# Clamp annotation > 2026-05-18 12:19pm
https://universe.roboflow.com/hazems-workspace-9vs3c/clamp-annotation-ghhu2

Provided by a Roboflow user
License: CC BY 4.0

